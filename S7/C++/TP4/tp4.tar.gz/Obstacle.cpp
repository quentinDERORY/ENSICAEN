#include <iostream>
#include <Obstacle.h>

/**
 * @file Obstacle.cpp
 * @author Mauranyapin Jean-Baptiste 
 * @auhor Derory Quentin
 * @version 1.0
 * @date 13 novembre 2014
 * */


Obstacle::~Obstacle(){
  orphelin=false;
}
